/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.Date;

/**
 *
 * @author JoaoSantos
 */
public class Employee_TF implements EmployeeInterface{
    

    @Override
    public String start(Date date) {
        return "Start -" + date;
    }

    @Override
    public String terminate(Date date) {
        return "Terminate -" + date;
    }

    @Override
    public String work() {
        return "work";
    }
    
}

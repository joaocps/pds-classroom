/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

/**
 *
 * @author JoaoSantos
 */
public class TeamMember extends Decorator {
    
    public TeamMember(EmployeeInterface employee) {
        super(employee);
    }
    
    public String colaborate(){
        return "colaborate";
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

/**
 *
 * @author JoaoSantos
 */
public class Main_class {

    public static void main(String[] args) {

        EmployeeInterface Employee_TF = new Employee_TF();
        Manager manager = new Manager(Employee_TF);
        TeamLeader teamLeader = new TeamLeader(Employee_TF);
        TeamLeader teamLeaderManager = new TeamLeader(new Manager(Employee_TF));

        System.out.println(manager.manage());
        System.out.println(teamLeader.plan());
        System.out.println(((Manager) teamLeaderManager.employee).manage());
        System.out.println(teamLeaderManager.plan());
        System.out.println(teamLeaderManager.work());

    }

}

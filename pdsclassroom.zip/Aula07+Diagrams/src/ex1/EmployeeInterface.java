/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.Date;

/**
 *
 * @author JoaoSantos
 */
public interface EmployeeInterface {
    
    String start(Date date);
    
    String terminate(Date date);
    
    String work();
    
}

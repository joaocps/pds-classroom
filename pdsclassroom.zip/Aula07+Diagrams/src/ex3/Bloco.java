/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author JoaoSantos
 */
class Bloco implements Component {

    private List<Component> component;
    private String name;

    public Bloco(String name) {
        this.name = name;
        component = new ArrayList<>();
    }

    public boolean add(Component comp) {
        return component.add(comp);
    }

    public String getName() {
        return name;
    }

    @Override
    public void draw() {
        System.out.println("Window " + name);
        for (Component c : component) {
            System.out.print("\t");
            c.draw();
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

import java.io.FileNotFoundException;

/**
 *
 * @author JoaoSantos
 */
public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        
        ImplementText reader;

        reader = new TextReader("Exemplo.txt");
        if (!reader.hasNext()) {
            System.out.println("TextReader -> hasNext(): " + reader.hasNext());
        }
        while (reader.hasNext()) {
            System.out.println("TextReader -> next(): " + reader.next());
        }

        reader = new CoderFilter(new TextReader("Exemplo.txt"));
        if (!reader.hasNext()) {
            System.out.println("CoderFilter -> hasNext(): " + reader.hasNext());
        }
        while (reader.hasNext()) {
            System.out.println("CoderFilter -> next(): " + reader.next());
        }

        reader = new ReverseFilter(new TermFilter(new TextReader("Exemplo.txt")));
        if (!reader.hasNext()) {
            System.out.println("ReverseFilter -> hasNext(): " + reader.hasNext());
        }
        while (reader.hasNext()) {
            System.out.println("ReverseFilter -> next(): " + reader.next());
        }

        reader = new CoderFilter(new ReverseFilter(new TextReader("Exemplo_zero.txt")));
        if (!reader.hasNext()) {
            System.out.println("CoderFilter - ReverseFilter -> hasNext(): " + reader.hasNext());
        }

    }
}

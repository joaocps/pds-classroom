/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

import java.util.Scanner;

/**
 *
 * @author JoaoSantos
 */
class ReverseFilter extends DecoratorText {

    Scanner sc = new Scanner(System.in);
    
    public ReverseFilter(ImplementText implement) {
		super(implement);
		sc = new Scanner("");
	}
	
	@Override
	public boolean hasNext() {
		if(!sc.hasNext())
			return implement.hasNext();
		else
			return true;
	}
	
	@Override
	public String next() {
		if(!sc.hasNext())
			sc = new Scanner(implement.next());
		return invertWord(sc.next());
	}
	
	private String invertWord(String word) {
		StringBuilder sb = new StringBuilder();
		for(int i=word.length()-1; i>=0; i--)
			sb.append(word.charAt(i));
		return sb.toString();
	}
    
}

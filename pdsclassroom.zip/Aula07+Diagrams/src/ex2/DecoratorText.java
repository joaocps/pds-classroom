/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

/**
 *
 * @author JoaoSantos
 */
public abstract class DecoratorText implements ImplementText {

    protected ImplementText implement;

    public DecoratorText(ImplementText implement) {
        this.implement = implement;
    }

    @Override
    public boolean hasNext() {
        return implement.hasNext();
    }

    @Override
    public String next() {
        return implement.next();
    }

}

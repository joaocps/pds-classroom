/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author JoaoSantos
 */
class TextReader implements ImplementText {

    Scanner sc = new Scanner(System.in);
    
    public TextReader(String fileName) throws FileNotFoundException {
        File firstFile = new File(fileName);
        sc = new Scanner(firstFile);
        sc.useDelimiter("(\\.)(\\s?)(\n)");
    }

    public TextReader(File firstFile) throws FileNotFoundException {
        sc = new Scanner(firstFile);
    }

    @Override
    public boolean hasNext() {
        return sc.hasNext();
    }

    @Override
    public String next() {
        String paragraph = sc.next();
        return paragraph.trim().endsWith(".") ? paragraph : paragraph + ".";
    }

}

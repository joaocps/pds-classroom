/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

import java.util.Scanner;

/**
 *
 * @author JoaoSantos
 */
class TermFilter extends DecoratorText {

    Scanner sc = new Scanner(System.in);

    public TermFilter(ImplementText implement) {
        super(implement);
        sc = new Scanner("");
    }

    @Override
    public boolean hasNext() {
        if (!sc.hasNext()) {
            return implement.hasNext();
        } else {
            return true;
        }
    }

    @Override
    public String next() {
        if (!sc.hasNext()) {
            sc = new Scanner(implement.next());
            return sc.next();
        } else {
            return sc.next();
        }
    }

}

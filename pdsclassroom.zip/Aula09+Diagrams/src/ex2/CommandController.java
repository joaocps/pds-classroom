/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

/**
 *
 * @author JoaoSantos
 */
public class CommandController {
    
    private ReversableCommand commmand;
	
	public ReversableCommand getCommmand() {
		return commmand;
	}

	public void setCommmand(ReversableCommand commmand) {
		this.commmand = commmand;
	}
	public void executeCommand(){
		commmand.doCommand();
	}
    
}

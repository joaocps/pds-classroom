/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author JoaoSantos
 */
public class Controller_test {
    
    	public static void main(String[] args) {
		List<String> stringList = new ArrayList<>();
		CollectionReceiver<String> structure = new CollectionReceiver<>(stringList);
		
		CommandController controler = new CommandController();
		ReversableCommand addHello = new AddCommand<String>(structure, "Hello");
		ReversableCommand addWorld = new AddCommand<String>(structure, "World");
		ReversableCommand undo = new UndoCommand<>(structure);
		
		controler.setCommmand(addHello);
		controler.executeCommand();
		controler.setCommmand(addWorld);
		controler.executeCommand();
		System.out.println(structure);
		controler.setCommmand(undo);
		controler.executeCommand();
		System.out.println(structure);
	}
}

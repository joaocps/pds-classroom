/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 *
 * @author JoaoSantos
 */
public class CollectionReceiver<T> {

    private Collection<T> colect;
    private Collection<T> previousCollection;

    public CollectionReceiver(Collection<T> collection) {
        this.colect = previousCollection = collection;
    }

    public void add(T element) {

        saveState();
        colect.add(element);
    }

    public void remove(T element) {

        saveState();
        colect.remove(element);

    }

    private void saveState() {
        previousCollection = cloneCollection();
    }

    public void undo() {

        checkUndos();
        colect = previousCollection;
        previousCollection = null;
    }

    private void checkUndos() {
        if (previousCollection == null) {
            throw new IllegalStateException("...");
        }
    }

    public String toString() {
        return colect.toString();
    }

    private Collection<T> cloneCollection() {
        Collection<T> tmp = new ArrayList<>();
        for (Iterator<T> it = colect.iterator(); it.hasNext();) {
            tmp.add(it.next());
        }
        return tmp;
    }

}

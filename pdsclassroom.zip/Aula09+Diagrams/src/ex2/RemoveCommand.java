/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

/**
 *
 * @author JoaoSantos
 */
public class RemoveCommand<T> implements ReversableCommand{

    private T removeElement;
    private CollectionReceiver<T> receiver;

    public RemoveCommand(CollectionReceiver<T> receiver, T element) {
        this.receiver = receiver;
        this.removeElement = element;
    }

    @Override
    public void doCommand() {
        receiver.remove(removeElement);
    }

    public T getElement() {
        return removeElement;
    }
}

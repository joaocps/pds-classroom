/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2;

/**
 *
 * @author JoaoSantos
 */
public class AddCommand<T> implements ReversableCommand {

    private T addElement;
    private CollectionReceiver<T> receiver;

    public AddCommand(CollectionReceiver<T> receiver, T element) {
        this.receiver = receiver;
        this.addElement = element;
    }

    @Override
    public void doCommand() {
        receiver.add(addElement);
    }

    public T getElement() {
        return addElement;
    }

}

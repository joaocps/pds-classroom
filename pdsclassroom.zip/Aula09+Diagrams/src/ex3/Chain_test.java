/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author JoaoSantos
 */
public class Chain_test {

    public static void main(String[] args) {

        List<String> commands = new ArrayList<>();
        commands.add("cria");
        commands.add("recupera");
        commands.add("atualiza");
        commands.add("cria");
        commands.add("apaga");
        commands.add("atualiza");
        commands.add("elimina");

        List<String> elements = new ArrayList<>();
        elements.add("1");
        elements.add("2");
        elements.add("3");
        elements.add("4");
        elements.add("5");

        CRUD crud = new Cria(new Recupera(new Atualiza(new Apaga())));
        for (String text : commands) {
            crud.useCommand(text, elements);
        }
        System.out.println("Elementos atualizados: " + elements);
    }
}

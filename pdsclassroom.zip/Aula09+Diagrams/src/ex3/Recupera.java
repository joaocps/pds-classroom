/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

import java.util.List;

/**
 *
 * @author JoaoSantos
 */
class Recupera extends CRUD {

    public Recupera(CRUD successor) {
        this.setSucessor(successor);
    }

    public void useCommand(String text, List<String> elements) {
        if (validCommand(text, getClass().getSimpleName())) {
            write();
        } else {
            super.useCommand(text, elements);
        }
    }

    @Override
    void write() {
        System.out.println("Recupera");
    }

}

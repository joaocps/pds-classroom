/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

import java.util.List;

/**
 *
 * @author JoaoSantos
 */
class Apaga extends CRUD {

    public Apaga() {
    }

    public void useCommand(String text, List<String> elements) {
        if (validCommand(text, getClass().getSimpleName())) {
            elements.remove(elements.size() - 1);
            write();
        } else {
            super.useCommand(text, elements);
        }
    }

    @Override
    protected void write() {
        System.out.println("Apaga");
    }

}

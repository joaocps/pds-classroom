/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

import java.util.List;

/**
 *
 * @author JoaoSantos
 */
public abstract class CRUD {
	private CRUD successor;
	
	public CRUD getSucessor() {
		return successor;
	}
	
	public void setSucessor(CRUD successor) {
		this.successor = successor;
	}
	
	public void useCommand(String text, List<String> elements) {
		if(getSucessor() != null)
			getSucessor().useCommand(text, elements);
		else
			System.err.println("not found");
	}
	
	public boolean validCommand(String text, String command) {
		return text.equalsIgnoreCase(command);
	}
	
	 abstract void write();
}

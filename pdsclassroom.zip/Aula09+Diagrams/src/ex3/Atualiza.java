/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

import java.util.List;

/**
 *
 * @author JoaoSantos
 */
class Atualiza extends CRUD {

    public Atualiza(CRUD successor) {
        this.setSucessor(successor);
    }

    public void useCommand(String text, List<String> elements) {
        if (validCommand(text, getClass().getSimpleName())) {
            String value = elements.get(elements.size() - 1);
            elements.remove(elements.size() - 1);
            elements.add(value + " Atualizado");
            write();
        } else {
            super.useCommand(text, elements);
        }
    }


    /* Atualiza(Apaga apaga) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }*/
    @Override
    protected void write() {
        System.out.println("Atualiza");
    }

}

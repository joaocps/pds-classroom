/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 *
 * @author JoaoSantos
 */
public class VectorGeneric<T> {

    private T[] vec;
    private int nElem;
    private final static int ALLOC = 50;
    private int dimVec = ALLOC;

    @SuppressWarnings("unchecked")
    public VectorGeneric() {
        vec = (T[]) new Object[dimVec];
        nElem = 0;
    }

    public boolean addElem(T elem) {
        if (elem == null) {
            return false;
        }
        ensureSpace();
        vec[nElem++] = elem;
        return true;
    }

    private void ensureSpace() {
        if (nElem >= dimVec) {
            dimVec += ALLOC;
            @SuppressWarnings("unchecked")
            T[] newArray = (T[]) new Object[dimVec];
            System.arraycopy(vec, 0, newArray, 0, nElem);
            vec = newArray;
        }
    }

    public boolean removeElem(T elem) {
        for (int i = 0; i < nElem; i++) {
            if (vec[i].equals(elem)) {
                if (nElem - i - 1 > 0) // not last element
                {
                    System.arraycopy(vec, i + 1, vec, i, nElem - i - 1);
                }
                vec[--nElem] = null; // libertar último objecto para o GC
                return true;
            }
        }
        return false;
    }

    public int totalElem() {
        return nElem;
    }

    public T getElem(int i) {
        return (T) vec[i];
    }

    public Iterator<T> iterator() {
        return new VectorIterator<>();
    }

    public VectorListIterator<T> listIterator() {
        return new VectorListIterator<>(0);
    }

    public VectorListIterator<T> listIterator(int index) {
        return new VectorListIterator<>(index);
    }

    private class VectorIterator<E> implements Iterator<E> {

        private int index = 0;

        @Override
        public boolean hasNext() {
            return (index < nElem);
        }

        @SuppressWarnings("unchecked")
        @Override
        public E next() {
            if (hasNext()) {
                return (E) vec[index++];
            }
            throw new NoSuchElementException("Vazio");
        }

    }

    private class VectorListIterator<E> implements ListIterator<E> {

        private int nextIndex;
        private int prevIndex;

        public VectorListIterator(int index) {
            nextIndex = index;
            prevIndex = nElem - index - 1;
        }

        @Override
        public boolean hasNext() {
            return (nextIndex < nElem);
        }

        @SuppressWarnings("unchecked")
        @Override
        public E next() {
            if (hasNext()) {
                return (E) vec[nextIndex++];
            }
            throw new NoSuchElementException("Vazio");
        }

        @Override
        public boolean hasPrevious() {
            return (prevIndex >= 0);
        }

        @SuppressWarnings("unchecked")
        @Override
        public E previous() {
            if (hasPrevious()) {
                return (E) vec[prevIndex--];
            }
            throw new NoSuchElementException("Vazio");
        }

        @Override
        public int nextIndex() {
            return nextIndex + 1;
        }

        @Override
        public int previousIndex() {
            return prevIndex - 1;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void set(E e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void add(E e) {
            throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

    }
}

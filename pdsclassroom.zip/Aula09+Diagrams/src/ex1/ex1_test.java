/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.Iterator;
import java.util.ListIterator;

/**
 *
 * @author JoaoSantos
 */
public class ex1_test {

    public static void main(String[] args) {
        
        //itera sobre as listas, inclui previous.
        
        VectorGeneric<Integer> generic = new VectorGeneric<>();
        for (int i = 0; i < 10; i++) {
            generic.addElem(i);
        }

        for (Iterator<Integer> it = generic.iterator(); it.hasNext();) {
            System.out.println("Iterator: " + it.next());
        }

        for (ListIterator<Integer> lit = generic.listIterator(0); lit.hasNext();) {
            System.out.println("ListIterator next:" + lit.next());
        }

        for (ListIterator<Integer> lit = generic.listIterator(5); lit.hasPrevious();) {
            System.out.println("ListIterator previous:" + lit.previous());
        }
    }
}

package pds_aula03;

public class JGalo_model implements JGaloInterface {

	private char[][] grid = new char[3][3];
	private char turn;
	private int nPlays = 0;
	private char winner = ' ';

	public JGalo_model() {
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				grid[i][j] = ' ';
			}
		}
		this.turn = 'x';
		this.nPlays = 0;
	}

	@Override
	public char getActualPlayer() {
		return this.turn;
	}

	@Override
	public boolean setJogada(int lin, int col) {
		char curTurn = this.getActualPlayer();
		if (grid[lin - 1][col - 1] == ' ') {
			this.nPlays++;
			grid[lin - 1][col - 1] = curTurn;
			switch (curTurn) {
			case 'x':
				this.turn = 'o';
				break;
			case 'o':
				this.turn = 'x';
				break;
			}
			return true;
		}
		return false;
	}

	@Override
	public boolean isFinished() {
		String diagonal1 = "";
		String diagonal2 = "";

		for (int i = 0; i < 3; i++) {
			String linha = "";
			String coluna = "";
			for (int j = 0; j < 3; j++) {
				linha += grid[i][j];
				coluna += grid[j][i];
			}
			diagonal1 += grid[i][i];
			diagonal2 += grid[i][2 - i];

			if (linha.equals("xxx") || linha.equals("ooo")) {
				this.winner = linha.charAt(0);
				return true;
			}
			if (coluna.equals("xxx") || coluna.equals("ooo")) {
				this.winner = coluna.charAt(0);
				return true;
			}
		}
		if (diagonal1.equals("xxx") || diagonal1.equals("ooo")) {
			this.winner = diagonal1.charAt(0);
			return true;
		}
		if (diagonal2.equals("xxx") || diagonal2.equals("ooo")) {
}
		if (this.nPlays == 9) {
			this.winner = ' ';
			return true;
		}
		return false;
	}

	@Override
	public char checkResult() {
		return this.winner;
	}

}

package pds_aula03;

public class Main {

	public static void main(String[] args) {
		
		JGalo_model modelo = new JGalo_model();
		
		JGalo_controller jogo = new JGalo_controller(modelo, new JGalo_view(modelo));

	}

}

package pds_aula03;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JToggleButton;

public class JGalo_controller implements ActionListener {
	private JGalo_model jogo;
	private JGalo_view view;
	private JToggleButton[] bt = new JToggleButton[9];
	
	public JGalo_controller(JGalo_model model, JGalo_view view) {
		this.bt = view.getBt();
		this.jogo = model;
		this.view = view;
		this.setListener();
	}
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().getClass().getSimpleName().equals("JToggleButton")){
			((JToggleButton)e.getSource()).setText(String.valueOf(jogo.getActualPlayer()));
			((JToggleButton)e.getSource()).setEnabled(false);
		}
		
		for (int i=0; i<9; i++)
			if (e.getSource()==this.bt[i]) {
				jogo.setJogada(i/3+1,i%3+1);
			}

		if (jogo.isFinished()){
			char result = jogo.checkResult();
			if (result == ' ')
				JOptionPane.showMessageDialog(this.view.getContentPane(), "Empate!");
			else
				JOptionPane.showMessageDialog(this.view.getContentPane(), "Venceu o jogador " + result);
			System.exit(0);
		}
	}
	
	public void setListener() {
		for (int i=0; i<9; i++) {
			bt[i].addActionListener(this);				
		}
	}

}

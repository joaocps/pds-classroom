package pds_aula03_02;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Collectors;
import java.util.Iterator;
import java.util.List;

// 
/**
 * The Class StreetMap.
 */
public class StreetMap {
	
	/** Maps a door number to a list of families*/
	private Map<Integer, Set<Family>> doorMap = new TreeMap<>();
	
	/** List of families that live in the street */
	private Set<Family> familyList = new HashSet<Family>();
	
	/** List of members that live in the street */
	private Set<Member> memberList = new TreeSet<Member>();
	
	/** The highest door number that is occupied by a family */
	private int highestNumber = 0;
	
	/**
	 * Find a family using the first and last interval of a range
	 * Creates a new family if it doesn't find any
	 * 
	 * @param x1 the x 1
	 * @param x2 the x 2
	 * @return the family
	 */
	public Family findFamily(int x1, int x2) {
		Family newFamily = new Family(x1, x2);
		for(Family fam : familyList) {
			if(fam.equals(newFamily)) {
				return fam;
			}
		}
		if(highestNumber < x2) {
			highestNumber = x2;
		}
		return newFamily;
	}
	
	/**
	 * Adds a family to the family list
	 *
	 * @param fam the fam
	 */
	public void addFamily(Family fam) {
		familyList.add(fam);
	}
	
	/**
	 * Adds a member to the member list
	 *
	 * @param name the name
	 * @param x1 the x 1
	 * @param x2 the x 2
	 */
	public void addMember(String name, int x1, int x2) {
		this.memberList.add(new Member(name, x1, x2));
	}

	/**
	 * Inserts a family into a door number
	 *
	 * @param i the i
	 * @param memberFam the member fam
	 */
	public void populate(int i, Family memberFam) {
		if(!doorMap.containsKey(i)) {
			doorMap.put(i, new HashSet<>());
		}
		doorMap.get(i).add(memberFam);
	}
	
	/**
	 * Removes a member from the family
	 *
	 * @param name the name
	 */
	public void removeFromFamily(String name) {
		Member newMember = new Member(name,0,0);
		for(Family f : familyList) {
			if(f.findMember(newMember)); {
				f.removeMember(newMember);
			}
		}
	}
	
	/**
	 * Show the street map
	 */
	public void showMap() {
		String sb = "";
		for(int i = 1; i <= highestNumber; i++) {
			sb += i + " : ";
			if(doorMap.containsKey(i)) {
				List<Family> famList = doorMap.get(i).stream()
					  	.sorted(Comparator.comparing((Family::getRange))
						.reversed())
					  	.collect(Collectors.toList());
				Iterator<Family> it = famList.iterator();
				if(it.hasNext()) {
					sb +=it.next();
				}
				while(it.hasNext()) {
					sb += " : " + it.next();
				}
			}

			sb += "\n";
		}
		System.out.println(sb);
		}

	
	/**
	 * List every member sorted Alphabetically
	 */
	public void listPeople() {
	
		for(Member m : memberList) {
			String sb = m.toString() + " ";
			for(int i = m.getX1() ; i <= m.getX2(); i++) {
				sb += i + " ";
			}
			System.out.println(sb);
		}
	}
	
	/**
	 * Lookup a member.
	 *
	 * @param name the name
	 */
	public void lookupMember(String name) {
		for(Family fam : familyList) {
			if(fam.findMember(new Member(name,0,0))) {
				System.out.println(fam.getX1() + " " + fam.getX2() + " : " + fam.toString());
				return;
			}
		}
		System.out.println("Not found");
	}
	
	/**
	 * Clear the map
	 */
	public void clear() {
		doorMap = new TreeMap<>();
		familyList = new HashSet<Family>();
		memberList = new TreeSet<Member>();
		highestNumber = 0;
	}
}


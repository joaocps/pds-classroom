package pds_aula03_02;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The Class Family.
 */
public class Family  {
	
	/** Members of the family. */
	List<Member> memberList = new ArrayList<>();
	
	/** First interval of the range */
	private int x1;
	
	/** Second interval of the range */
	private int x2;
	
	/** Number of doors occupied */
	private int range;
	
	/**
	 * Instantiates a new family.
	 *
	 * @param x1 the x 1
	 * @param x2 the x 2
	 */
	public Family(int x1, int x2) {
		this.x1 = x1;
		this.x2 = x2;
		this.range = x2 - x1;
	}
	
	/**
	 * Gets the range.
	 *
	 * @return the range
	 */
	public int getRange() {
		return range;
	}
	
	/**
	 * Check if a member is part of the family
	 *
	 * @param memberFind the member to find
	 * @return true, if successful
	 */
	public boolean findMember(Member memberFind) {
		for(Member m : memberList) {
			if(m.equals(memberFind)) {
				return true;
			}
		}
		return false;
	}
	
	/**
	 * Gets the x1.
	 *
	 * @return the x1
	 */
	public int getX1() {
		return x1;
	}

	/**
	 * Gets the x2.
	 *
	 * @return the x2
	 */
	public int getX2() {
		return x2;
	}

	/**
	 * Removes a member from the fmaily
	 *
	 * @param toRemove the member to remove
	 */
	public void removeMember(Member toRemove) {
		Iterator<Member> iterator = memberList.iterator();
		while (iterator.hasNext()) {
		    Member element = iterator.next();
		    if (element.equals(toRemove)) {
		        iterator.remove();
		    }
		}
	}

	/**
	 * Creates a new member and adds it to the family
	 *
	 * @param name the name of the member to add
	 */
	public void addMember(String name) {
		Member newMember = new Member(name,this.x1,this.x2);
		for(Member m : memberList) {
			if(m.equals(newMember)) {
				System.out.println("Error: Member already exists");
				return;
			}
		}
		this.memberList.add(newMember);
	}
	
	
	/**
	 * Gets the member list.
	 *
	 * @return the member list
	 */
	public List<Member> getMemberList() {
		return memberList;
	}

	@Override
	public String toString() {
		String sb = "";
		for(Member m : memberList) {
			sb += m + " ";
		}
		return sb;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + x1;
		result = prime * result + x2;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Family other = (Family) obj;
		if (x1 != other.x1)
			return false;
		if (x2 != other.x2)
			return false;
		return true;
	}

}

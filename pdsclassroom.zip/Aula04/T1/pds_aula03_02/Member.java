package pds_aula03_02;

/**
 * The Class Member.
 */
public class Member implements Comparable<Member>{
	
	/** The name. */
	private String name;
	
	/** First interval of the range */
	private int x1;
	
	/** Second interval of the range */
	private int x2;
	
	/**
	 * Gets the x1.
	 *
	 * @return the x1
	 */
	public int getX1() {
		return x1;
	}

	/**
	 * Gets the x2.
	 *
	 * @return the x2
	 */
	public int getX2() {
		return x2;
	}

	/**
	 * Instantiates a new member.
	 *
	 * @param name the name
	 * @param x1 the x 1
	 * @param x2 the x 2
	 */
	public Member(String name, int x1, int x2) {
		this.name = name;
		this.x1 = x1;
		this.x2 = x2;
	}
	
	@Override
	public String toString() {
		return this.name;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	/* 
	 * A member is equal if it has the same name
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Member other = (Member) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	/* 
	 * Alphabetical order
	 */
	@Override
	public int compareTo(Member o) {
		return this.name.toLowerCase().compareTo(o.name.toLowerCase());
	}
	
	
}

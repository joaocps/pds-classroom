package pds_aula03_02;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

// TODO: Auto-generated Javadoc
/**
 * The Class Main.
 */
public class Main {
	
	/**  Static scanner to handle commands. */
	static Scanner sc = new Scanner(System.in);
	
	/**  Instantiate a map. */
	static StreetMap map = new StreetMap();

	/**
	 * The main method.
	 *
	 * @param args the arguments
	 * @throws FileNotFoundException the file not found exception
	 */
	public static void main(String[] args) throws FileNotFoundException {

		/**
		 * Reads a file with commands and parses them
		 * 
		 */
		if (args.length > 0) {
			Scanner argsc = new Scanner(new File(args[0]));
			while (argsc.hasNextLine()) {
				String[] commandParsed = argsc.nextLine().split(" ");
				try {
					menuParse(commandParsed);
				} catch ( ArrayIndexOutOfBoundsException e) {
					System.out.println("Invalid command");
				}
				
			}
			argsc.close();
		}
		
		/**
		 * Menu
		 */
		while (true) {
			System.out.println("Available commands: Load, Map, Add, Remove, List, Lookup, Clear, Quit");
			String input = sc.nextLine().toLowerCase();
			String[] parsedInput = input.split(" ");
			try {
				menuParse(parsedInput);
			} catch ( FileNotFoundException e ) {
				System.out.println("File not found");
			} catch (ArrayIndexOutOfBoundsException e  ) {
				System.out.println("Invalid command");
			} catch (NumberFormatException e ) {
				System.out.println("Invalid command");
			}
			
		}
	}

	/**
	 * Parses a user command.
	 *
	 * @param parsedInput the parsed input
	 * @throws FileNotFoundException the file not found exception
	 */
	public static void menuParse(String[] parsedInput) throws FileNotFoundException {
		switch (parsedInput[0]) {
		case "load":
			loadFile(parsedInput[1]);
			break;
		case "map":
			map.showMap();
			break;
		case "add":
			generateFamily(Integer.parseInt(parsedInput[2]), Integer.parseInt(parsedInput[3]), parsedInput[1]);
			break;
		case "remove":
			map.removeFromFamily(parsedInput[1]);
			break;
		case "list":
			map.listPeople();
			break;
		case "lookup":
			map.lookupMember(parsedInput[1]);
			break;
		case "clear":
			map.clear();
			break;
		case "quit":
			System.exit(0);
			break;
		default:
			System.out.println("Command not found");
			break;
		}
	}

	/**
	 * Loads a file and generates the families.
	 *
	 * @param fileName the file name
	 * @throws FileNotFoundException the file not found exception
	 */
	public static void loadFile(String fileName) throws FileNotFoundException {
		Scanner file = new Scanner(new File(fileName));

		// so para testes, corrigir no fim
		file.nextLine();
		String[] parsedLine;
		while (file.hasNextLine()) {
			parsedLine = file.nextLine().split(" |-");
			generateFamily(Integer.parseInt(parsedLine[0]), Integer.parseInt(parsedLine[1]), parsedLine[2]);
		}
	}

	/**
	 * Generate family.
	 * Validates the name, adds new member to a family and populates the map
	 *
	 * @param x1 the x 1
	 * @param x2 the x 2
	 * @param name the name
	 */
	public static void generateFamily(int x1, int x2, String name) {
		if(!validateName(name)) {
			System.out.println("Invalid name");
			return;
		}
		Family memberFam = map.findFamily(x1, x2); //Returns a new family if it can't find one with the same range
		memberFam.addMember(name);
		map.addFamily(memberFam);
		map.addMember(name, x1, x2);
		for (int i = x1; i <= x2; i++) {
			map.populate(i, memberFam);
		}
	}
	
	/**
	 * Validates a name
	 * Rules:
	 * 		- Max length is 40
	 * 		- Can only contain letters, digits and these symbols: _.@author Bernardo
	 * 		- Must start with a letter
	 * 		- Can't end with a symbol
	 *
	 * @param name the name
	 * @return true, if successful
	 */
	public static boolean validateName(String name) {
		if(!name.matches("^[A-Za-z].*[\\w_.@].*[\\w]$") || name.length() > 40) {
			return false;
		}
		return true;
	}
}

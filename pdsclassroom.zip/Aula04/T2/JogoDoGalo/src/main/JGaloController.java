/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JToggleButton;

/**
 *
 * @author miguel
 */
public class JGaloController implements ActionListener {

    private JGaloView view;
    private JGaloModel model;

    public JGaloController(JGaloView view, JGaloModel model) {
        this.view = view;
        this.model = model;

        setListeners();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource().getClass().getSimpleName().equals("JToggleButton")) {
            ((JToggleButton) e.getSource()).setText(String.valueOf(model.getActualPlayer()));
            ((JToggleButton) e.getSource()).setEnabled(false);
        }
        JToggleButton bt[] = view.getButtons();
        for (int i = 0; i < 9; i++) {
            if (e.getSource() == bt[i]) {
                model.setJogada(i / 3 + 1, i % 3 + 1);
            }
        }

        if (model.isFinished()) {
            char result = model.checkResult();
            if (result == ' ') {
                JOptionPane.showMessageDialog(view.getContentPane(), "Empate!");
            } else {
                JOptionPane.showMessageDialog(view.getContentPane(), "Venceu o jogador " + result);
            }
            System.exit(0);
        }
        model.changeTurn();
    }

    private void setListeners() {
        JToggleButton bt[] = view.getButtons();

        for (int i = 0; i < bt.length; i++) {
            bt[i].addActionListener(this);
        }
    }
    
}

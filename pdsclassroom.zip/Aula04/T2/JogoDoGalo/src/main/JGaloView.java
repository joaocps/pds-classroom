package main;

import javax.swing.JFrame;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JPanel;
import java.awt.GridLayout;

import javax.swing.JToggleButton;

public class JGaloView extends JFrame {

    private static final long serialVersionUID = -3780928537820216588L;
    private JPanel jPanel = null;
    private JToggleButton bt[];

    public JGaloView() {
        super("Jogo da Galinha");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 300);
        setLocation(100, 100);
        jPanel = new JPanel();
        jPanel.setLayout(new GridLayout(3, 3));
        bt = new JToggleButton[9];
        for (int i = 0; i < 9; i++) {
            bt[i] = new JToggleButton();
            bt[i].setFont(new Font("Tahoma", Font.BOLD, 50));
            bt[i].setForeground(Color.BLUE);
            jPanel.add(bt[i]);
        }

        this.setContentPane(jPanel);
        setVisible(true);
    }

    public JToggleButton[] getButtons() {
        return bt;
    }
}

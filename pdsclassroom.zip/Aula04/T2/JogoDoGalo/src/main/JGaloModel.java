/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author miguel
 */
public class JGaloModel implements JGaloInterface {

    private char[][] grid;
    private char turn;
    private int nPlays;
    private char winner;

    public JGaloModel(char firstPlayer) {
        turn = firstPlayer;
        nPlays = 0;
        grid = new char[3][3];
        winner = ' ';

        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid.length; j++) {
                grid[i][j] = ' ';
            }
        }
    }

    @Override
    public char getActualPlayer() {
        return turn;
    }

    @Override
    public boolean setJogada(int lin, int col) {
        if (lin < 1 || lin > 3 || col < 1 || col > 3) {
            return false;
        }
        if (grid[lin - 1][col - 1] == ' ') {
            grid[lin - 1][col - 1] = turn;
            nPlays++;

            return true;
        }
        return false;
    }

    // se mudar de turno na função setJogada, 
    // o turno da funçao isFinished fica incorreto
    // portanto optei por mudar de turno depois da execuçao da funçao isFinished
    // no controller
    public void changeTurn() {
        turn = (turn == 'X') ? 'O' : 'X';
    }

    @Override
    public boolean isFinished() {

        //horizontal
        for (int i = 0; i < grid.length; i++) {
            int count = 0;
            for (int j = 0; j < grid.length; j++) {
                if (grid[i][j] == turn) {
                    count++;
                }
            }
            if (count == 3) {
                winner = turn;
                return true;
            }
        }

        //vertical
        for (int i = 0; i < grid.length; i++) {
            int count = 0;
            for (int j = 0; j < grid.length; j++) {
                if (grid[j][i] == turn) {
                    count++;
                }
            }
            if (count == 3) {
                winner = turn;
                return true;
            }
        }

        //diagonal
        if (grid[0][0] == turn && grid[1][1] == turn && grid[2][2] == turn) {
            winner = turn;
            return true;
        }

        if (grid[0][2] == turn && grid[1][1] == turn && grid[2][0] == turn) {
            winner = turn;
            return true;
        }

        //empate
        if (nPlays == 9) {
            return true;
        }

        return false;
    }

    @Override
    public char checkResult() {
        return winner;
    }

}

#!/bin/bash

chmod 777 dist/Rua.jar

java -jar dist/Rua.jar commands1.txt

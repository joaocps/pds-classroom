/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author miguel
 */
public class Street {

    private Map<Integer, List<Family>> doors;

    public Street() {
        doors = new TreeMap<>();
    }

    public boolean removeMember(String name) throws StreetException {
        Family family = getFamilyByMember(name);
        if (family != null) {
            if (family.getNumberOfMembers() == 1) {
                for (int door : doors.keySet()) {
                    Iterator<Family> it = doors.get(door).iterator();
                    while (it.hasNext()) {
                        Family f = it.next();
                        if (f.equals(family)) {
                            it.remove();
                        }
                    }
                }
            } else {
                family.removeMember(name);
            }
            return true;
        }
        return false;
    }

    public Family getFamilyByMember(String name) throws StreetException {
        for (int door : doors.keySet()) {
            for (Family f : doors.get(door)) {
                if (f.hasMember(name)) {
                    return f;
                }
            }
        }
        throw new StreetException("There are no members named \"" + name + "\"");
    }

    public void addMember(int x1, int x2, String name) throws StreetException {
        Family family = new Family(x1, x2, name);
        if (doors.containsKey(x1)) {
            if (doors.get(x1).contains(family)) {
                doors.get(x1).get(doors.get(x1).indexOf(family)).addMember(name);
                return;
            }
        }
        for (int i = x1; i <= x2; i++) {
            if (doors.containsKey(i)) {
                doors.get(i).add(family);
                Collections.sort(doors.get(i));
            } else {
                doors.put(i, new ArrayList<>(Arrays.asList(family)));
            }
        }
    }

    public String listAllMembers() {
        StringBuilder sb = new StringBuilder();
        List<Family> families = new ArrayList<>();

        for (int door : doors.keySet()) {
            for (Family f : doors.get(door)) {
                if (!families.contains(f)) {
                    families.add(f);
                }
            }
        }
        for (Family f : families) {
            List<String> members = f.getMembers();
            Collections.sort(members);
            for (String member : members) {
                sb.append(member);
                sb.append(" ");
                sb.append(f.getX1());
                sb.append(" ");
                sb.append(f.getX2());
                sb.append("\n");
            }
        }
        return sb.toString();
    }

    public void clear() {
        doors.clear();
    }

    @Override
    public String toString() {
        StringBuilder line = new StringBuilder();
        StringBuilder sb = new StringBuilder();
        Map<Family, Integer> charPostition = new HashMap<>();

        for (int door : doors.keySet()) {
            line.append(door);

            for (Family f : doors.get(door)) {
                if (charPostition.containsKey(f)) {

                    int whiteSpaces = charPostition.get(f) - line.length();

                    for (int i = 0; i < whiteSpaces; i++) {
                        line.append(" ");
                    }
                    line.append(f);

                } else {
                    charPostition.put(f, line.length());
                    line.append(f);
                }
            }
            sb.append(line);
            sb.append("\n");
            line.delete(0, line.length());
        }
        return sb.toString();
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.io.File;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author miguel
 */
public class Main {

    private static final String CHARSET = "UTF-8";

    private static final String COMMANDS = "Load, Map, Add, Remove, List, Lookup, Clear, Quit";

    private static Scanner sc = new Scanner(System.in);

    private static Street street = new Street();

    public static void main(String[] args) {

        if (args.length > 1) {
            System.out.println("USAGE: java Main commands.txt");
            System.exit(1);
        } else if (args.length == 1) {
            try {
                commandsFromFile(args[0]);
            } catch (StreetException ex) {
                System.out.println(ex.getMessage());
            }
        }

        while (true) {
            System.out.println("");
            System.out.println(COMMANDS);
            System.out.print("Command: ");
            String line = sc.nextLine();
            processCommand(line);
        }
    }

    private static void commandsFromFile(String fileName) throws StreetException {
        File file = new File(fileName);

        try (Scanner sc = new Scanner(file, CHARSET)) {
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                processCommand(line);
            }
        } catch (Exception e) {
            throw new StreetException(e.getMessage(), e);
        }
    }

    private static void load(String fileName) throws StreetException {
        File file = new File(fileName);
        try (Scanner sc = new Scanner(file, CHARSET)) {
            sc.nextLine();
            while (sc.hasNextLine()) {
                String line = sc.nextLine();

                String[] parts = line.split(" ");

                if (parts.length != 2) {
                    throw new StreetException("File not structered properly.");
                }

                String[] numbers = parts[0].split("-");

                if (numbers.length != 2) {
                    throw new StreetException("File not structered properly.");
                }
                street.addMember(Integer.parseInt(numbers[0]), Integer.parseInt(numbers[1]), parts[1]);
            }

        } catch (Exception e) {
            throw new StreetException(e.getMessage(), e);
        }
    }

    private static void processCommand(String command) {

        String[] commands = command.split(" ");
        int nCommands = commands.length;

        switch (commands[0].toLowerCase()) {
            case "load":
                if (nCommands != 2) {
                    System.out.println("USAGE: Load filename");
                    return;
                }
                 {
                    try {
                        load(commands[1]);
                    } catch (StreetException ex) {
                        System.out.println(ex.getMessage());
                    }
                }
                break;

            case "map":
                System.out.println(street);
                break;

            case "add":
                if (nCommands != 4) {
                    System.out.println("USAGE: Add name x1 x2");
                    return;
                }
                try {
                    street.addMember(Integer.parseInt(commands[2]), Integer.parseInt(commands[3]), commands[1]);
                } catch (NumberFormatException ex) {
                    System.out.println("Invalid number. " + ex.getMessage());
                } catch (StreetException ex) {
                    System.out.println(ex.getMessage());
                }
                break;

            case "remove":
                if (nCommands != 2) {
                    System.out.println("USAGE: Remove name");
                    return;
                }
                try {
                    street.removeMember(commands[1]);
                } catch (StreetException ex) {
                    System.out.println(ex.getMessage());
                }
                break;

            case "list":
                System.out.println(street.listAllMembers());
                break;

            case "lookup":
                if (nCommands != 2) {
                    System.out.println("USAGE: Lookup name");
                    return;
                }
                Family family;
                try {
                    family = street.getFamilyByMember(commands[1]);
                } catch (StreetException ex) {
                    System.out.println(ex.getMessage());
                    return;
                }
                System.out.printf("%-2d %-2d%s %n", family.getX1(), family.getX2(), family);
                break;

            case "clear":
                street.clear();
                break;
            case "quit":
                System.exit(0);
                break;

            default:
                System.out.println("Invalid Command.");

        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author miguel
 */
public class Family implements Comparable<Family> {

    private List<String> members;
    private int x1;
    private int x2;

    public Family(int x1, int x2, String firstMember) throws StreetException {
        if (x1 < 1) {
            throw new StreetException("Port numbers start at 1.");
        }
        if (x1 > x2) {
            throw new StreetException("x1 cant be grater than x2.");
        }
        this.members = new ArrayList<>();
        addMember(firstMember);
        this.x1 = x1;
        this.x2 = x2;
    }

    public void addMember(String name) throws StreetException {
        if (!Character.isAlphabetic(name.charAt(0))) {
            throw new StreetException("A name must start with a letter.");
        }
        int lastChar = name.length() - 1;
        if (!Character.isDigit(name.charAt(lastChar)) && !Character.isAlphabetic(name.charAt(lastChar))) {
            throw new StreetException("A name cant end with a symbol.");
        }
        if (name.length() > 40) {
            throw new StreetException("The maximum length of a name is 40.");
        }
        if (!name.matches("[a-zA-z0-9_.@]+")) {
            throw new StreetException("A name must have only letters, numbers, and the symbols: _.@");
        }
        members.add(name);
    }

    public void removeMember(String name) {
        members.remove(name);
    }

    public boolean hasMember(String name) {
        return members.contains(name);
    }

    public int getNumberOfMembers() {
        return members.size();
    }

    public List<String> getMembers() {
        return new ArrayList<>(members);
    }

    public int getX1() {
        return x1;
    }

    public int getX2() {
        return x2;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(" :");
        for (String s : members) {
            sb.append(" ");
            sb.append(s);
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + this.x1;
        hash = 97 * hash + this.x2;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Family other = (Family) obj;
        if (this.x1 != other.x1) {
            return false;
        }
        if (this.x2 != other.x2) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Family o) {
        if (this.x1 > o.x1) {
            return 1;
        }
        if (this.x1 < o.x1) {
            return -1;
        }
        if (this.x1 == o.x1) {
            int alcance_this = this.x2 - this.x1;
            int alcance_o = o.x2 - o.x1;

            if (alcance_this > alcance_o) {
                return -1;
            }

            if (alcance_this < alcance_o) {
                return 1;
            }
        }
        return 0;
    }
}

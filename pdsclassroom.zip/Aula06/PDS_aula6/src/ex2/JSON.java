package Lab06_02;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class JSON implements ContactsStorageInterface {

    private String Ficheiro = "contactos.json";

    @Override
    public List<Contact> loadContacts() {
        // TODO Auto-generated method stub
        List<Contact> lista = new ArrayList<>();
        Scanner input = null;
        try {
            File ficheiro = new File(Ficheiro);
            input = new Scanner(new FileInputStream(ficheiro));
            while (input.hasNextLine()) {
                int Telefone = 0;
                String Nome = null;
                String Endereco = null;
                String v = input.nextLine();
                String[] inp = v.split(", ");
                if (inp.length != 1) {
                    for (int i = 0; i < inp.length; i++) {
                        String[] inp1 = inp[i].split(":");
                        switch (i) {
                            case 0:
                                Nome = inp1[1].replace("\"", "");
                                break;
                            case 1:
                                Telefone = Integer.parseInt(inp1[1].replace("\"", ""));
                                break;
                            case 2:
                                Endereco = inp1[1].replace("\"", "").replace("},", "").replace("}", "");
                                break;
                        }
                    }
                    Contact contacto = new Contact(Nome, Telefone, Endereco);
                    lista.add(contacto);
                }

            }

        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
        input.close();
        return lista;
    }

    @Override
    public boolean saveContacts(List<Contact> list) {
        // TODO Auto-generated method stub
        boolean guardar = false;
        try {
            File ficheiro = new File(Ficheiro);
            PrintWriter pw = new PrintWriter(ficheiro);
            pw.println("{\"Contacts\":[");
            int i = 0;
            for (Contact v : list) {
                if (i != 0) {
                    pw.println(",");
                }
                pw.print("\t");
                pw.print("{\"Nome\":" + "\"" + v.getNome() + "\", \"Telefone\":" + "\"" + v.getNumeroDeTelefone() + "\", \"Endere�o\":" + "\"" + v.getEndereco() + "\"}");
                i++;
            }
            pw.println();
            pw.println("]}");
            pw.close();
            guardar = true;
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
        return guardar;
    }

}

package Lab06_02;

import java.util.ArrayList;
import java.util.List;

public class Contactos_Store implements ContactsInterface {

    private List<Contact> lista = new ArrayList<>();

    @Override
    public void openAndLoad(ContactsStorageInterface store) {
        // TODO Auto-generated method stub
        lista = store.loadContacts();
        System.out.println(store.getClass().getSimpleName() + ":" + lista);
    }

    @Override
    public void saveAndClose() {
        // TODO Auto-generated method stub
        int rando = 1 + (int) (4 * Math.random());
        boolean store = false;
        switch (rando) {
            case 1:
                store = new TXT().saveContacts(lista);
                break;
            case 2:
                store = new BIN().saveContacts(lista);
                break;
            case 3:
                store = new CSV().saveContacts(lista);
                break;
            case 4:
                store = new JSON().saveContacts(lista);
                break;
        }
    }

    @Override
    public void saveAndClose(ContactsStorageInterface store) {
        // TODO Auto-generated method stub
        if (!store.saveContacts(lista)) {
        }
    }

    @Override
    public boolean exist(Contact contact) {
        // TODO Auto-generated method stub
        boolean saida = false;
        for (Contact contacto : lista) {
            if (contacto.getNome().equals(contact.getNome())) {
                saida = true;
            }
        }
        return saida;
    }

    @Override
    public Contact getByName(String name) {
        // TODO Auto-generated method stub
        Contact contacto = null;
        for (Contact contacto1 : lista) {
            if (contacto1.getNome().equals(name)) {
                contacto = contacto1;
            }
        }
        return contacto;
    }

    @Override
    public boolean add(Contact contact) {
        // TODO Auto-generated method stub
        boolean adicionar = false;
        if (exist(contact) == false) {
            lista.add(contact);
            adicionar = true;
        }
        return adicionar;
    }

    @Override
    public boolean remove(Contact contact) {
        // TODO Auto-generated method stub
        boolean remover = false;
        if (exist(contact) == true) {
            lista.remove(contact);
            remover = true;
        }
        return remover;
    }

}

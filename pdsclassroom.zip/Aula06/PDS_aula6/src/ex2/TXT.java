package Lab06_02;

import java.io.File;
import java.io.FileInputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TXT implements ContactsStorageInterface {

    private String Ficheiro = "contactos.txt";

    @Override
    public List<Contact> loadContacts() {
        // TODO Auto-generated method stub
        List<Contact> lista = new ArrayList<>();
        Scanner input = null;
        try {
            File ficheiro = new File(Ficheiro);
            input = new Scanner(new FileInputStream(ficheiro));
            while (input.hasNextLine()) {
                String[] inp = input.nextLine().split("\t");
                Contact contacto = new Contact(inp[0], Integer.parseInt(inp[1]), inp[2]);
                lista.add(contacto);
            }
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
        input.close();
        return lista;
    }

    @Override
    public boolean saveContacts(List<Contact> list) {
        // TODO Auto-generated method stub
        boolean guardar = false;
        try {
            File ficheiro = new File(Ficheiro);
            PrintWriter pw = new PrintWriter(ficheiro);
            for (Contact v : list) {
                pw.printf("%s\t%d\t%s", v.getNome(), v.getNumeroDeTelefone(), v.getEndereco());
                pw.println();
            }
            pw.close();
            guardar = true;
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
        return false;
    }
}

package Lab06_02;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class BIN implements ContactsStorageInterface {

    private String Ficheiro = "contactos.bin";

    @Override
    public List<Contact> loadContacts() {
        // TODO Auto-generated method stub
        List<Contact> lista = new ArrayList<>();
        try {
            FileInputStream ficheiro = new FileInputStream(Ficheiro);
            BufferedReader leitor = new BufferedReader(new InputStreamReader(ficheiro));
            String linha;
            while ((linha = leitor.readLine()) != null) {
                String[] palavras = linha.split("\t");
                Contact contacto = new Contact(palavras[0], Integer.parseInt(palavras[1]), palavras[2]);
                lista.add(contacto);
            }
            ficheiro.close();
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
        return lista;
    }

    @Override
    public boolean saveContacts(List<Contact> list) {
        // TODO Auto-generated method stub
        boolean guardar = false;
        try {
            FileOutputStream ficheiro = new FileOutputStream(Ficheiro);
            for (Contact lista : list) {
                String v = String.format("%s\t%d\t%s\n", lista.getNome(), lista.getNumeroDeTelefone(), lista.getEndereco());
                ficheiro.write(v.getBytes());
            }
            ficheiro.close();
            guardar = true;
        } catch (Exception e) {
            System.out.println("Error:" + e);
        }
        return guardar;

    }

}

package Lab06_02;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ContactsInterface contact = new Contactos_Store();
        Scanner sc = new Scanner(System.in);
        System.out.println("Introduza o nome, telefone, localidade: Nome,Telefone,Localidade: !!");
        System.out.println("Caso deseje sair digite (quit): ");
        while (true) {
            String input = sc.nextLine();
            if (input != "quit") {
                String[] contacto = input.split(",");
                String nome = contacto[0];
                int numero = Integer.parseInt(contacto[1]);
                String endereco = contacto[2];
                Contact cont = new Contact(nome, numero, endereco);
                contact.add(cont);
                ContactsStorageInterface file1 = new TXT();
                ContactsStorageInterface file2 = new CSV();
                ContactsStorageInterface file3 = new JSON();
                ContactsStorageInterface file4 = new BIN();
                contact.saveAndClose(file1);
                contact.saveAndClose(file2);
                contact.saveAndClose(file3);
                contact.saveAndClose(file4);
                contact.openAndLoad(file1);
                contact.openAndLoad(file2);
                contact.openAndLoad(file3);
                contact.openAndLoad(file4);
            }
            if (input == "quit") {
                break;
            }
        }

    }

}

package Lab06_02;

public class Contact {

    private String Nome;
    private int NumeroDeTelefone;
    private String Endereco;

    public Contact(String nome, int numeroDeTelefone, String endereco) {
        super();
        this.Nome = nome;
        this.NumeroDeTelefone = numeroDeTelefone;
        this.Endereco = endereco;
    }

    public String getNome() {
        return Nome;
    }

    public int getNumeroDeTelefone() {
        return NumeroDeTelefone;
    }

    public String getEndereco() {
        return Endereco;
    }

    @Override
    public String toString() {
        return "Contact [Nome=" + Nome + ", NumeroDeTelefone="
                + NumeroDeTelefone + ", Endereco=" + Endereco + "]";
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package reflection1;

import com.sun.webkit.plugin.PluginManager;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import reflection.IPlugin;

/**
 *
 * @author JoaoSantos
 */
public class Plugin {

    public static void main(String[] args) throws Exception {
        
        File proxyList = new File("reflection/plugins");
        ArrayList<IPlugin> plgs = new ArrayList<IPlugin>();
        for (String f : proxyList.list()) {
            System.out.println(f);
            try {
                if(f.equals("IPlugin.java")) continue;
                plgs.add(PluginManager.load("reflection." + f.substring(0, f.lastIndexOf('.'))));
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        Iterator<IPlugin> it = plgs.iterator();
        while (it.hasNext()) {
            it.next().fazQualQuerCoisa();
        }
    }
}

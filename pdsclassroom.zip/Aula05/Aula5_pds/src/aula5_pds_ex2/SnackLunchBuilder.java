package Lab05_02;

public class SnackLunchBuilder implements LunchBuilder {
	
	private Lunch lunch;
	public SnackLunchBuilder() {
		lunch = new Lunch();
	}
	
	@Override
	public void buildDrink() {
		// TODO Auto-generated method stub
		lunch.setDrink("Sumo");		
	}
	
	@Override
	public void buildMainCourse() {
		// TODO Auto-generated method stub
		lunch.setMainCourse("Pao com Panado");		
	}
	
	@Override
	public void buildSide() {
		// TODO Auto-generated method stub
		lunch.setSide("Rissol");		
	}
	
	@Override
	public Lunch getMeal() {
		// TODO Auto-generated method stub
		return lunch;
	}

}

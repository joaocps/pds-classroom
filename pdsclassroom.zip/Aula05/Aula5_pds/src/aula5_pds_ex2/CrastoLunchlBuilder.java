package Lab05_02;

public class CrastoLunchlBuilder implements LunchBuilder {
		
	private Lunch lunch;
	public CrastoLunchlBuilder() {
		lunch=new Lunch();
	}
	
	@Override
	public void buildDrink() {
		// TODO Auto-generated method stub
		lunch.setDrink("Vinho Tinto");
	}

	@Override
	public void buildMainCourse() {
		// TODO Auto-generated method stub
		lunch.setMainCourse("Bacalhau á lagareiro");
	}

	@Override
	public void buildSide() {
		// TODO Auto-generated method stub
		lunch.setSide("Broa");
	}

	@Override
	public Lunch getMeal() {
		// TODO Auto-generated method stub
		return lunch;
	}

}

package Lab05_02;

interface LunchBuilder {
	public void buildDrink();
	public void buildMainCourse();
	public void buildSide();
	public Lunch getMeal();

}

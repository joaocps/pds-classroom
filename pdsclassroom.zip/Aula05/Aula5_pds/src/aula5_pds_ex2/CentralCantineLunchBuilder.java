package Lab05_02;

public class CentralCantineLunchBuilder implements LunchBuilder {

	private Lunch lunch;
	public CentralCantineLunchBuilder() {
		lunch=new Lunch();
	}
	
	@Override
	public void buildDrink() {
		// TODO Auto-generated method stub
		lunch.setDrink("água");
	}

	@Override
	public void buildMainCourse() {
		// TODO Auto-generated method stub
		lunch.setMainCourse("Grelhada Mista");
	}

	@Override
	public void buildSide() {
		// TODO Auto-generated method stub
		lunch.setSide("Queijo fresco");
	}

	@Override
	public Lunch getMeal() {
		// TODO Auto-generated method stub
		return lunch;
	}

}

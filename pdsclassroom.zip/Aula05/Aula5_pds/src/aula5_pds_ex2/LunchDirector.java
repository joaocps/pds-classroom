package Lab05_02;

public class LunchDirector {
	
	private LunchBuilder luch;
	public LunchDirector(LunchBuilder lunch) {
		luch=lunch;
	}

	public void constructMeal() {
		luch.buildDrink();
		luch.buildMainCourse();
		luch.buildSide();
	}

	public Lunch getMeal() {
		return luch.getMeal();
	}
	

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula5_pds_ex3;

/**
 *
 * @author JoaoSantos
 */
public class Main_ex3 {

    public static void main(String[] args) {
        Person person = new Person.Builder("Santos", "João", "Pinto", false).streetAddress("Avenida dos Aliados").build();
        System.out.println(person.toString());
    }

}

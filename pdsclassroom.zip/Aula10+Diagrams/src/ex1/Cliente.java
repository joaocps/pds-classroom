/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.ArrayList;

/**
 *
 * @author JoaoSantos
 */
public class Cliente extends Observer{

    private String nome;

    public Cliente(String nome) {
        this.nome = nome;
        subject = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }
    
    public void licitar(Subject subj, double licitacao){
        subj.licitar(this, licitacao);
        subject.add(subj);
    }
    
    @Override
    void update(String mensagem) {
        System.out.println("Cliente " + nome + ":" + mensagem);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.Random;

/**
 *
 * @author JoaoSantos
 */
public class Main {
    public static void main(String[] args) {
        
        Produto[] produtos ={new Produto(1,"Camisola FCPorto Autografada",50),
                             new Produto(2,"BMW X5 Usado/Gasoleo/2015",42000),
                             new Produto(3,"Oculos de Sol",20),
                             new Produto(4,"Sapatilhas Nike Air Force",60),
                             new Produto(5,"Bilhetes Final Champions", 40)};
        Gestor gestor = new Gestor("Pinto da Costa");
        Cliente[] clientes = { new Cliente("João"), new Cliente("Pedro"), new Cliente("André") };
        Broker broker = new Broker();
        
        for (int i = 0; i < produtos.length; i++) {
            produtos[i].setEstado(EstadoProduto.stock);
            broker.addProduto(produtos[i]);
        }
        
        for (int i = 0; i < produtos.length; i++) {
            Subject subj = broker.createSubject(3, produtos[i].getCodigo());
            
            for (Cliente c : clientes) {
                double bit = new Random().nextDouble() * (produtos[i].getPreco() * 10);
                subj.licitar(c, bit);
            }
    }
}
}

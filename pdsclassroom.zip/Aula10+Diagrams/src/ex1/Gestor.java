/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author JoaoSantos
 */
class Gestor extends Observer {
    
    private String nome;
    private List<Produto> produtos;

    public Gestor(String nome) {
        this.nome = nome;
        produtos = new ArrayList<>();
        subject = new ArrayList<>();
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public List<Produto> getProdutos() {
        return produtos;
    }

    public void setProdutos(Produto prod) {
        produtos.add(prod);
    }
    
    public void addSubject(Subject subj) {
        subject.add(subj);
    }
    
    public void addProduto(Produto produto){
        produtos.add(produto);
    }

    @Override
    void update(String mensagem) {
        System.out.println("Gestor" + nome + ":" + mensagem);
        
    }
    
}

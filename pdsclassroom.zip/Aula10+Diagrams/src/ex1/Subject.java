/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author JoaoSantos
 */
class Subject {

    private Produto produto;
    private double ultima_licitacao;
    private List<Observer> observers;
    private int tempo_licitacao;

    public Subject(Produto produto, int tempo_licitacao, List<Gestor> gestor) {

        observers = new ArrayList<>();
        observers.addAll(gestor);
        ultima_licitacao = 0;
        this.produto = produto;
        this.tempo_licitacao = tempo_licitacao;
    }

    public Produto getProduto() {
        return produto;
    }

    public double getUltima_licitacao() {
        return ultima_licitacao;
    }

    public void setEstado(EstadoProduto estado) {
        produto.setEstado(estado);
        if (estado == EstadoProduto.vendas) {
            notifyObservers(true);
        }
    }

    public void licitar(Observer obs, double licitacao) {

        if (produto.getEstado() != EstadoProduto.leilao) {
            System.out.println("Produto não está em Leilão");
        } else if (ultima_licitacao == 0 && licitacao >= produto.getPreco()) {
            ultima_licitacao = licitacao;
            observers.add(obs);
            notifyObservers(false);
        } else if (licitacao > ultima_licitacao){
            ultima_licitacao = licitacao;
            observers.add(obs);
            notifyObservers(true);
        }
    }

    private void notifyObservers(boolean notify) {
        List<Gestor> gestores = parseGestores(observers);
        if (notify) {
            observers.stream().forEach(obs -> obs.update(enviar(notify)));
        } else {
            gestores.stream().forEach(obs -> obs.update(enviar(notify)));
        }
    }

    private List<Gestor> parseGestores(List<Observer> observers) {
        List<Gestor> gestores = new ArrayList<>();
        for (Observer obs : observers) {
            if (obs instanceof Gestor) {
                gestores.add((Gestor) obs);
            }
        }
        return gestores;
    }

    private String enviar(boolean notify) {

        StringBuilder sb = new StringBuilder();
        if (produto.getEstado() == EstadoProduto.leilao && notify == false) {
            sb.append("Nova Licitação efetuada : " + produto.getCodigo());
        }
        if (produto.getEstado() == EstadoProduto.leilao && notify == true) {
            sb.append("Licitação superior! A ultima licitação do produto ");
            sb.append(produto.getCodigo() + "é agora: ");
            sb.append(String.format("%.2f", ultima_licitacao).toString() + "€");
        } else if (produto.getEstado() == EstadoProduto.vendas) {
            sb.append("Produto " + produto.getCodigo());
            sb.append(" vendido por " + String.format("%.2f", ultima_licitacao) + "€");
        }
        return sb.toString();
    }

}

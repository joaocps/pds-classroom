/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author JoaoSantos
 */
public class Broker {

    private List<Produto> produtos;
    private List<Subject> subjects;
    private List<Observer> observers;
    private List<Gestor> gestores;

    public Broker() {
        produtos = new ArrayList<>();
        subjects = new ArrayList<>();
        observers = new ArrayList<>();
        gestores = new ArrayList<>();
    }

    public void addGestor(Gestor gestor) {
        gestores.add(gestor);
        observers.add(gestor);
    }

    public void addProduto(Produto produto) {
        produtos.add(produto);
        for (Gestor g : gestores) {
            g.addProduto(produto);
        }
    }

    public Subject createSubject(int tempo, int codigo) {
        Produto produto = findProduct(codigo);
        Subject subject = null;
        if (produto != null && produto.getEstado() != null) {
            subject = registerSubject(tempo, produto);
            tempoLeilao(subject, tempo);
        }
        return subject;
    }

    private void tempoLeilao(Subject subject, int tempo) {
        Timer timer = new Timer();
        TimerTask auctionTask = new TempoLeilao(subject);
        timer.schedule(auctionTask, tempo * 1000);
    }

    private Subject registerSubject(int tempo, Produto produto) {
        Subject subject = new Subject(produto, tempo, gestores);
        subject.setEstado(EstadoProduto.leilao);
        subjects.add(subject);
        for (Gestor g : gestores) {
            g.addSubject(subject);
        }
        return subject;
    }

    private Produto findProduct(int codigo) {
        Produto p = null;
        for (Produto prod : produtos) {
            if (prod.getCodigo() == codigo) {
                p = prod;
            }
        }
        return p;
    }

    public String listPrducts() {
        StringBuilder sb = new StringBuilder();
        produtos.stream().forEach(prod -> sb.append(prod.toString()));
        return sb.toString();
    }
}

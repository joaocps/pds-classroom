/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.TimerTask;

/**
 *
 * @author JoaoSantos
 */
public class TempoLeilao extends TimerTask {

    private Subject subject;

    public TempoLeilao(Subject subject) {
        this.subject = subject;
    }
    
    @Override
    public void run() {
        if(subject.getUltima_licitacao() == 0){
            subject.setEstado(EstadoProduto.stock);
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

/**
 *
 * @author JoaoSantos
 */
public class Livro {

    private String titulo;
    private int ISBN;
    private int ano;
    private Autor primeiroAutor;
    private EstadoLivro estadoAtual;

    public Livro(String titulo, int ISBN, int ano, Autor primeiroAutor) {
        this.titulo = titulo;
        this.ISBN = ISBN;
        this.ano = ano;
        this.primeiroAutor = primeiroAutor;
        estadoAtual = new Inventario();
    }

    public EstadoLivro getEstadoAtual() {
        return estadoAtual;
    }
    
    public void setEstadoAtual(EstadoLivro estadoAtual) {
        this.estadoAtual = estadoAtual;
    }

    public void registar() {
        estadoAtual.registar(this);
    }

    public void requisitar() {
        estadoAtual.requisitar(this);
    }

    public void devolver() {
        estadoAtual.devolver(this);
    }

    public void reservar() {
        estadoAtual.reservar(this);
    }

    public void cancelaReserva() {
        estadoAtual.cancelaReserva(this);
    }

    @Override
    public String toString() {
        return "Livro{" + "titulo=" + titulo + ", ISBN=" + ISBN + ", ano=" + ano + ", primeiroAutor=" + primeiroAutor + ", estadoAtual=" + estadoAtual + '}';
    }

    public String getTitulo() {
        return titulo;
    }

    public int getISBN() {
        return ISBN;
    }

    public int getAno() {
        return ano;
    }

    public Autor getPrimeiroAutor() {
        return primeiroAutor;
    }
    
    

}

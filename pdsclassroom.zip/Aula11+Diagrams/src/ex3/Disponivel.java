/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

/**
 *
 * @author JoaoSantos
 */
public class Disponivel implements EstadoLivro {

    @Override
    public void registar(Livro livro) {
        throw new IllegalStateException();
    }

    @Override
    public void requisitar(Livro livro) {
        livro.setEstadoAtual(new Emprestimo());
    }

    @Override
    public void reservar(Livro livro) {
        livro.setEstadoAtual(new Reserva());
    }

    @Override
    public void cancelaReserva(Livro livro) {
        throw new IllegalStateException();
    }

    @Override
    public void devolver(Livro livro) {
        throw new IllegalStateException();
    }
    
    public String toString(){
        return "[DISPONIVEL]";
    }

}

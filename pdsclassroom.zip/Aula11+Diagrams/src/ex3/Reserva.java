/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

/**
 *
 * @author JoaoSantos
 */
public class Reserva implements EstadoLivro {

    @Override
    public void registar(Livro livro) {
        throw new IllegalStateException();
    }

    @Override
    public void requisitar(Livro livro) {
        throw new IllegalStateException();
    }

    @Override
    public void reservar(Livro livro) {
        throw new IllegalStateException();
    }

    @Override
    public void cancelaReserva(Livro livro) {
        livro.setEstadoAtual(new Disponivel());
    }

    @Override
    public void devolver(Livro livro) {
        throw new IllegalStateException();
    }
    
    public String toString() {
        return "[RESERVADO]";
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author JoaoSantos
 */
public class Main {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        List<Livro> livros = new ArrayList<>();
        livros.add(new Livro("Padroes e Desenho de Software", 12345, 2010, new Autor("Antonio Silva")));
        livros.add(new Livro("Mecanica de Aeronaves", 25874, 2001, new Autor("Filipa Araujo")));
        livros.add(new Livro("FCPorto, A História", 26547, 1986, new Autor("Pinto da Costa")));

        while (true) {
            int[] op = menu(livros);
            Livro escolha = livros.get(op[0]-1);
            try {
                switch (op[1]) {
                    case 1:
                        escolha.registar();
                        break;
                    case 2:
                        escolha.requisitar();
                        break;
                    case 3:
                        escolha.reservar();
                        break;
                    case 4:
                        escolha.devolver();
                        break;
                    case 5:
                        escolha.cancelaReserva();
                        break;
                    default:
                        System.out.println("NUMERO INVALIDO");
                        System.exit(1);
                }
            } catch (IllegalStateException e) {
                System.err.println("Operaçõa invalida");
            }
        }

    }

    private static int[] menu(List<Livro> livros) {
        int[] op = new int[2];
        System.out.println("BIBLIOTECA");
        livros.forEach(b -> System.out.printf("%d  %s  %s\n", b.getISBN(), b.getTitulo(), b.getEstadoAtual().toString()));
        System.out.println(">> <livro>, <operação: (1)Registar; (2)Requisitar; (3)Reservar; (4)Devolver; (5)Cancelar");
        String[] line = sc.nextLine().split(",");
        op[0] = Integer.parseInt(line[0]);
        op[1] = Integer.parseInt(line[1]);
        return op;
    }
}

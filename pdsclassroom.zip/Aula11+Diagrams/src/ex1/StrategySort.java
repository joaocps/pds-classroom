/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.Comparator;
import java.util.List;

/**
 *
 * @author JoaoSantos
 */
public interface StrategySort {

    public List<Telemovel> sort(List<Telemovel> telemovel, Comparator<Telemovel> comparator);

}

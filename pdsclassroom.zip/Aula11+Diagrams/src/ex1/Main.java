/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author JoaoSantos
 */
public class Main {

    public static void main(String[] args) {

        Revista rev = new Revista("Revista de Telemoveis");
        List<Telemovel> telemoveis = new LinkedList<>();
        for (int i = 0; i < 10; i++) {
            telemoveis.add(Telemovel.buildRandomCellPhone());
        }
        rev.setRevista(telemoveis);
        System.out.println(rev.toString());
        System.out.println("Telemoveis ordenados por preço com InsertSort");
        System.out.println(rev.getpreco(new InsertSort()));

        System.out.println("Telemoveis ordenados por processador com SelectSort");
        System.out.println(rev.getprocessador(new SelectSort()));

        System.out.println("Telemoveis ordenados por memoria com BubbleSort");
        System.out.println(rev.getmemoria(new BubbleSort()));
    }
}
